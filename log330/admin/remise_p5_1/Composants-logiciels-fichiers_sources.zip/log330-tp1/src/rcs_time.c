/*
 * rcs_time.c
 *
 *  Created on: 2013-03-12
 *      Author: isra
 */

#include <time.h>

unsigned int rcs_time_get_tick() {
	return time(0);
}
