/*
 * rcs_temperature.c
 *
 *  Created on: 2013-03-14
 *      Author: isra
 */

#include "rcs_temperature.h"

char temp_input = 0;

float rcs_temperature_poll() {
	return F_TO_C(((float)temp_input/255.f) * (T_RANGE_MAX - T_RANGE_MIN) + T_RANGE_MIN);
}

void rcs_temperature_set_heater(float power /*Watt hour*/) {
	//Set the heater power...
}
