/*
 * rcs_input.c
 *
 *  Created on: 2013-03-12
 *      Author: isra
 */

#include "rcs_input.h"

rcs_input_t rcs_input_peek() {
	rcs_input_t input;
	input.pot_inserted = 1;
	input.soak = 0;
	input.start = 0;
	input.slow_mode = 0;
	input.normal_mode = 0;
	input.fast_mode = 0;

	return input;
}
