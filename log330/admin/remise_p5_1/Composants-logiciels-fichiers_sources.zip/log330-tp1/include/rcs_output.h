/*
 * rcs_output.h
 *
 *  Created on: 2013-03-12
 *      Author: isra
 */

#ifndef __RCS_OUTPUT_H_INCLUDED__
#define __RCS_OUTPUT_H_INCLUDED__

void rcs_output_set_alarm(char state);
void rcs_output_set_heating_display(char state);
void rcs_output_set_cooking_display(char state);

#endif /* RCS_OUTPUT_H_ */
