/*
 * rcs_input.h
 *
 *  Created on: 2013-03-12
 *      Author: isra
 */

#ifndef RCS_INPUT_H_
#define RCS_INPUT_H_

typedef struct rcs_input_t {
	char pot_inserted;
	char start;
	char soak;
	char slow_mode;
	char normal_mode;
	char fast_mode;
} rcs_input_t;

rcs_input_t rcs_input_peek();

#endif /* RCS_INPUT_H_ */
