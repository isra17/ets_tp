/*
 * rcs_mode_selected_state.h
 *
 *  Created on: 2013-03-12
 *      Author: isra
 */

#ifndef __RCS_MODE_SELECTED_STATE_H_INCLUDED__
#define __RCS_MODE_SELECTED_STATE_H_INCLUDED__

#include "rcs_state.h"

rcs_state_t* rcs_mode_selected_state_new();
void rcs_mode_selected_state_run();

#endif /* RCS_MODE_SELECTED_STATE_H_ */
